import React from "react"
import facebook_icon from "../images/FacebookIcon.png"
import github_icon from "../images/GitHubIcon.png"
import twitter_icon from "../images/TwitterIcon.png"

export default function Media(){
    return(
        <>
            <img src={facebook_icon}/>
            <img src={twitter_icon}/>
            <img src={github_icon}/>
        </>
    )
}