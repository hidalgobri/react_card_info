import React from "react";
import logo from "../images/foto-perfil.jpg";
import email_icon from "../images/Mail.png";
import linkedin_icon from "../images/linkedin.png";

export default function Introduction() {
  return (
    <div className="intrd">
      <img src={logo} />
      <h1>Valeria Hidalgo C</h1>
      <h4>Frontend Developer</h4>
      <p>valeriahidalgo50@gmail.com</p>
      <div className="intrd-buttons">
        <div className="button">
            <img src={email_icon} />
            <h4>Email </h4>
            
        </div>
        <div className="button">
            <img src={linkedin_icon} />
            <h4>LinkedIn </h4>
        </div>
      </div>
    </div>
  );
}
