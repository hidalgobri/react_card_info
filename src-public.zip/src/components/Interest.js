import React from "react";

export default function Interest() {
  return (
    <>
      <h2>Interest</h2>
      <p>
        Food expert. Music scholar. Reader. Internet fanatic. Bacon buff.
        Entrepreneur. Travel geek. Pop culture ninja. Coffee fanatic.
      </p>
    </>
  );
}
